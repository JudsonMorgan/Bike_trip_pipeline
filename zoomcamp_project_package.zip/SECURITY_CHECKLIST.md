
# Security Checklist for Zoomcamp Data Pipeline

## Credentials Management
- [x] Service Account Keys are never committed to Git.
- [x] Keys stored locally at ~/.gcp/gcp-key.json
- [x] .gitignore configured to exclude sensitive files.

## GCP Best Practices
- [x] Old service account keys deleted from GCP Console.
- [x] Rotated keys immediately after accidental exposure.

## Local Environment
- [x] Environment variables managed via .env
- [x] Environment variables loaded into Airflow and dbt.

## Git Hygiene
- [x] Used git filter-branch to clean sensitive files from history.
- [x] Forced push cleaned history to GitHub.

## Pipeline Orchestration
- [x] Airflow triggers dbt run after load_to_bq step.
- [x] dbt models structured as staging -> marts.

Stay Secure. Stay Pro.
